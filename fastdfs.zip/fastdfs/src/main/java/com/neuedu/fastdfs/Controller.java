package com.neuedu.fastdfs;

import com.alibaba.fastjson.JSONObject;
import org.csource.common.NameValuePair;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import sun.security.util.Length;

import java.io.*;

@RestController
@RequestMapping("/dfs")
public class Controller {
    @RequestMapping(value = "/{id}", method = RequestMethod.POST)
    public JSONObject uplaod(@PathVariable("id") String id, @RequestParam("file") MultipartFile file) {//1. 接受上传的文件  @RequestParam("file") MultipartFile file
        //编写图片上传的业务逻辑方法
        //获取图片名称
        String filename = file.getOriginalFilename();
        //获取图片扩展名
        String ext = filename.substring(filename.lastIndexOf(".") + 1);
        //生成图片名称
        String imgName = id;//自己写的一个获取字符串的方法作为图片名称
        //生成图片的存放在服务器的路径
        String path = "/imgs/" + imgName + "." + ext;

        //图片上传
        JSONObject jo = new JSONObject();
        try {
            InputStream in = file.getInputStream();
            byte[] bytes = new byte[10000000];//10M
            int len;
            while ( (len = in.read(bytes)) != -1);
            in.close();
            FastDFSFile fastDFSFile = new FastDFSFile(bytes,ext);
            NameValuePair[] meta_list = new NameValuePair[4];
            meta_list[0] = new NameValuePair("fileName", "abc");
            meta_list[1] = new NameValuePair("fileLength", String.valueOf(len));
            meta_list[2] = new NameValuePair("fileExt", ext);
            meta_list[3] = new NameValuePair("fileAuthor", "WangLiang");
            String filePath = FileManager.upload(fastDFSFile,meta_list);
            System.out.println(filePath);
            jo.put("url",filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return jo;
    }

}
